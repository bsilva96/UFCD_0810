// instrução para permitir ultrapassar a mensagem de erro
// do scanf()
#define _CRT_SECURE_NO_WARNINGS

//importar bilbiotecas para o nosso projeto
#include <stdio.h>
#include <stdlib.h>

void exercicio1() {
	//baseado no exercicio 2 da ficha 1
}

void exercicio2() {
	//baseado no exercicio 3 da ficha 1
}

void exercicio3() {
	//baseado no exercicio 5 da ficha 1
}

void main() {
	exercicio1();
	exercicio2();
	exercicio3();
}